const images = {};

export default images;
