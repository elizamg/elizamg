import { colors } from './colors';
const Themes = {
  colors,
};

export default Themes;
