# FitCast Hi-Fi Prototype
### CS 147 Autumn 2023
#### Class Site: https://hci.stanford.edu/courses/cs147/2023/au/projects.html
#### Project Site: https://web.stanford.edu/class/cs147/projects/UnintentionalGood/FitCast/


### CS 147L ReadMe
#### Since the 147 and 147L specs were a bit different, we created a version for both classes. Only the 147Lmodals branch contains the final code for the 147L version.
#### The full ReadMe as well as the exported app can be found here: https://docs.google.com/document/d/1QA855vnnBP0qiNhTy3YvgpQQELpxPBt_EKKmKkhqnnE/edit?usp=sharing

